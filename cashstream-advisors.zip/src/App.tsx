import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import TaxStrategy from './pages/TaxStrategy';
import Compliance from './pages/Compliance';
import Fema from './pages/Fema';
import Bookkeeping from './pages/Bookkeeping';
import ContractReview from './pages/ContractReview';
import Insights from './pages/Insights';
import GlobalOffices from './pages/GlobalOffices';
import Careers from './pages/Careers';
import CaseStudies from './pages/CaseStudies';
import PrivacyPolicy from './pages/PrivacyPolicy';
import RegulatoryCompliance from './pages/RegulatoryCompliance';
import TermsOfService from './pages/TermsOfService';

function ScrollToTop() {
  const { pathname } = useLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

export default function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen bg-surface flex flex-col">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/tax-strategy" element={<TaxStrategy />} />
            <Route path="/compliance" element={<Compliance />} />
            <Route path="/fema" element={<Fema />} />
            <Route path="/bookkeeping" element={<Bookkeeping />} />
            <Route path="/contract-review" element={<ContractReview />} />
            <Route path="/insights" element={<Insights />} />
            <Route path="/global-offices" element={<GlobalOffices />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/case-studies" element={<CaseStudies />} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/regulatory-compliance" element={<RegulatoryCompliance />} />
            <Route path="/terms-of-service" element={<TermsOfService />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

